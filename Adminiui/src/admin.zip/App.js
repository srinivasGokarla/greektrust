import logo from './logo.svg';
import './App.css';
import List from './Components/User';
function App() {
  return (
    <div className="App">
  <List />
    </div>
  );
}

export default App;
